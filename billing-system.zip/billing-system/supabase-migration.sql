-- ============================================================
-- CONTROLE DE COBRANÇAS · Fábrica Online
-- Execute este SQL no Supabase SQL Editor
-- ============================================================

CREATE TABLE IF NOT EXISTS cobrancas (
  id                BIGSERIAL PRIMARY KEY,
  codigo_cliente    TEXT NOT NULL,
  nome_cliente      TEXT,
  numero_nota       TEXT NOT NULL,
  valor_total       NUMERIC(12,2) NOT NULL DEFAULT 0,
  valor_recebido    NUMERIC(12,2) NOT NULL DEFAULT 0,
  forma_pagamento   TEXT DEFAULT 'Boleto',
  data_vencimento   DATE NOT NULL,
  status            TEXT DEFAULT 'Pendente',
  observacoes       TEXT,
  created_at        TIMESTAMPTZ DEFAULT NOW(),
  updated_at        TIMESTAMPTZ DEFAULT NOW()
);

-- Atualiza updated_at automaticamente
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_cobrancas_updated_at ON cobrancas;
CREATE TRIGGER trg_cobrancas_updated_at
  BEFORE UPDATE ON cobrancas
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Habilita Row Level Security com acesso público (sem login)
ALTER TABLE cobrancas ENABLE ROW LEVEL SECURITY;

CREATE POLICY "acesso_total" ON cobrancas
  FOR ALL USING (true) WITH CHECK (true);

-- Dados de exemplo (remova em produção)
INSERT INTO cobrancas (codigo_cliente, nome_cliente, numero_nota, valor_total, valor_recebido, forma_pagamento, data_vencimento, status, observacoes)
VALUES
  ('CLI-001', 'Indústria Alpha Ltda',  'NF-2024-0891', 18500.00, 0,       'Boleto',        '2024-03-10', 'Atrasado',    '3ª cobrança enviada'),
  ('CLI-002', 'Comércio Beta S/A',     'NF-2024-0892', 7200.00,  3600.00, 'Boleto',        '2024-03-15', 'Pago Parcial','50% recebido em 14/03'),
  ('CLI-003', 'Tech Solutions ME',     'NF-2024-0893', 4350.00,  4350.00, 'PIX',           '2024-03-20', 'Pago Total',  ''),
  ('CLI-001', 'Indústria Alpha Ltda',  'NF-2024-0894', 12000.00, 0,       'Transferência', '2024-04-05', 'Pendente',    'Aguardando aprovação'),
  ('CLI-004', 'Distribuidora Gama',    'NF-2024-0895', 9800.00,  0,       'Boleto',        '2024-03-05', 'Atrasado',    'Cliente em renegociação'),
  ('CLI-005', 'Grupo Delta Eireli',    'NF-2024-0896', 3150.00,  3150.00, 'Cartão',        '2024-03-28', 'Pago Total',  '');
