# 📊 Controle de Cobranças · Fábrica Online

Sistema web para controle de recebíveis e cobranças, com dashboard visual de boletos atrasados.

## ✨ Funcionalidades

- **Dashboard macro**: KPIs de atraso, pagamento parcial, recebidos e pendentes
- **Alerta de NFs atrasadas**: lista detalhada com dias de atraso e saldo devedor
- **Tabela completa**: busca, filtro por status, ordenação por qualquer coluna
- **CRUD completo**: cadastrar, editar, excluir cobranças
- **Confirmação de pagamento**: botão rápido para marcar NF como paga
- **Sinalização visual**: badge colorido por status + ponto vermelho pulsante em atraso
- **Banco compartilhado**: qualquer pessoa da empresa acessa o mesmo banco via URL

## 🚀 Setup em 5 passos

### 1. Criar projeto no Supabase (gratuito)
1. Acesse [supabase.com](https://supabase.com) e crie uma conta
2. Clique em **New Project** e preencha nome e senha
3. Aguarde inicializar (~2 min)

### 2. Criar a tabela
1. No painel do Supabase, clique em **SQL Editor**
2. Cole o conteúdo do arquivo `supabase-migration.sql`
3. Clique em **Run**

### 3. Obter as credenciais
1. Vá em **Settings → API**
2. Copie a **Project URL** e a **anon public key**

### 4. Configurar variáveis de ambiente
```bash
cp .env.example .env
# Edite .env e preencha com suas credenciais do Supabase
```

### 5. Rodar localmente
```bash
npm install
npm start
```

---

## 🌐 Deploy no GitHub Pages

### Configurar o repositório
```bash
git init
git add .
git commit -m "feat: controle de cobranças"
git remote add origin https://github.com/SEU_USUARIO/controle-cobrancas.git
git push -u origin main
```

### Configurar secrets no GitHub
1. Vá em **Settings → Secrets and variables → Actions**
2. Adicione:
   - `REACT_APP_SUPABASE_URL` → sua URL do Supabase
   - `REACT_APP_SUPABASE_ANON_KEY` → sua anon key

### Criar workflow de deploy
Crie o arquivo `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: 18

      - name: Install dependencies
        run: npm install

      - name: Build
        env:
          REACT_APP_SUPABASE_URL: ${{ secrets.REACT_APP_SUPABASE_URL }}
          REACT_APP_SUPABASE_ANON_KEY: ${{ secrets.REACT_APP_SUPABASE_ANON_KEY }}
        run: npm run build

      - name: Deploy
        uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./build
```

### Ativar GitHub Pages
1. Vá em **Settings → Pages**
2. Source: **Deploy from branch → gh-pages**
3. Acesse: `https://SEU_USUARIO.github.io/controle-cobrancas`

---

## 📋 Campos da cobrança

| Campo | Tipo | Descrição |
|-------|------|-----------|
| Código do Cliente | Texto | Identificador único do cliente |
| Nome do Cliente | Texto | Razão social ou nome |
| Número da NF | Texto | Número da nota fiscal |
| Valor Total | Monetário | Valor a ser recebido |
| Valor Recebido | Monetário | Quanto já foi pago |
| Forma de Pagamento | Seleção | Boleto, PIX, Transferência, Cartão, Cheque, Dinheiro |
| Data de Vencimento | Data | Prazo de pagamento |
| Status | Seleção | Pendente, Pago Parcial, Pago Total, Atrasado, Cancelado |
| Observações | Texto livre | Notas internas |

## 🔒 Segurança

O sistema usa **Row Level Security (RLS)** do Supabase com política de acesso público (sem login), ideal para uso interno da empresa. Para adicionar autenticação, consulte a [documentação do Supabase Auth](https://supabase.com/docs/guides/auth).

## 🛠 Tecnologias

- **React 18** — Interface
- **Supabase** — Banco de dados PostgreSQL na nuvem (gratuito)
- **Tailwind CSS** — Estilização
- **date-fns** — Manipulação de datas
- **lucide-react** — Ícones
- **GitHub Pages** — Hospedagem gratuita
