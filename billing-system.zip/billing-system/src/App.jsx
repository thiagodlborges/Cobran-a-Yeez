import { useState, useEffect, useCallback } from "react";
import { createClient } from "@supabase/supabase-js";
import {
  AlertTriangle, CheckCircle2, Clock, TrendingUp,
  Plus, Search, Filter, RefreshCw, FileText,
  DollarSign, XCircle, ChevronDown, ChevronUp, X, Save
} from "lucide-react";
import { format, isAfter, parseISO, differenceInDays } from "date-fns";
import { ptBR } from "date-fns/locale";

// ─── CONFIG ─────────────────────────────────────────────────────────────────
const SUPABASE_URL = process.env.REACT_APP_SUPABASE_URL || "";
const SUPABASE_KEY = process.env.REACT_APP_SUPABASE_ANON_KEY || "";
const supabase = SUPABASE_URL ? createClient(SUPABASE_URL, SUPABASE_KEY) : null;

const PAYMENT_FORMS = ["Boleto", "PIX", "Transferência", "Cartão", "Cheque", "Dinheiro"];
const STATUS_OPTIONS = ["Pendente", "Pago Parcial", "Pago Total", "Atrasado", "Cancelado"];

const STATUS_STYLE = {
  "Pendente":      { bg: "bg-amber-900/30", text: "text-amber-300", border: "border-amber-700/50", icon: Clock },
  "Pago Parcial":  { bg: "bg-blue-900/30",  text: "text-blue-300",  border: "border-blue-700/50",  icon: TrendingUp },
  "Pago Total":    { bg: "bg-emerald-900/30",text: "text-emerald-300",border:"border-emerald-700/50",icon: CheckCircle2 },
  "Atrasado":      { bg: "bg-red-900/30",   text: "text-red-400",   border: "border-red-700/50",   icon: AlertTriangle },
  "Cancelado":     { bg: "bg-zinc-800",     text: "text-zinc-400",  border: "border-zinc-700",     icon: XCircle },
};

const fmtBRL = (v) => Number(v || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const today  = () => new Date().toISOString().split("T")[0];

// ─── MOCK DATA (usado quando Supabase não está configurado) ──────────────────
const MOCK_DATA = [
  { id: 1, codigo_cliente: "CLI-001", nome_cliente: "Indústria Alpha Ltda", numero_nota: "NF-2024-0891", valor_total: 18500.00, valor_recebido: 0, forma_pagamento: "Boleto", data_vencimento: "2024-03-10", status: "Atrasado", observacoes: "3ª cobrança enviada", created_at: "2024-03-01" },
  { id: 2, codigo_cliente: "CLI-002", nome_cliente: "Comércio Beta S/A",    numero_nota: "NF-2024-0892", valor_total: 7200.00,  valor_recebido: 3600, forma_pagamento: "Boleto", data_vencimento: "2024-03-15", status: "Pago Parcial", observacoes: "50% recebido em 14/03", created_at: "2024-03-05" },
  { id: 3, codigo_cliente: "CLI-003", nome_cliente: "Tech Solutions ME",    numero_nota: "NF-2024-0893", valor_total: 4350.00,  valor_recebido: 4350, forma_pagamento: "PIX",    data_vencimento: "2024-03-20", status: "Pago Total",    observacoes: "", created_at: "2024-03-08" },
  { id: 4, codigo_cliente: "CLI-001", nome_cliente: "Indústria Alpha Ltda", numero_nota: "NF-2024-0894", valor_total: 12000.00, valor_recebido: 0, forma_pagamento: "Transferência", data_vencimento: "2024-04-05", status: "Pendente",   observacoes: "Aguardando aprovação", created_at: "2024-03-12" },
  { id: 5, codigo_cliente: "CLI-004", nome_cliente: "Distribuidora Gama",   numero_nota: "NF-2024-0895", valor_total: 9800.00,  valor_recebido: 0, forma_pagamento: "Boleto", data_vencimento: "2024-03-05", status: "Atrasado",     observacoes: "Cliente em renegociação", created_at: "2024-03-01" },
  { id: 6, codigo_cliente: "CLI-005", nome_cliente: "Grupo Delta Eireli",   numero_nota: "NF-2024-0896", valor_total: 3150.00,  valor_recebido: 3150, forma_pagamento: "Cartão", data_vencimento: "2024-03-28", status: "Pago Total",    observacoes: "", created_at: "2024-03-15" },
];

// ─── SUPABASE HELPERS ────────────────────────────────────────────────────────
async function fetchRows() {
  if (!supabase) return { data: MOCK_DATA, error: null };
  return supabase.from("cobrancas").select("*").order("data_vencimento", { ascending: true });
}
async function upsertRow(row) {
  if (!supabase) return { data: row, error: null };
  const { id, ...rest } = row;
  if (id) return supabase.from("cobrancas").update(rest).eq("id", id).select().single();
  return supabase.from("cobrancas").insert(rest).select().single();
}
async function deleteRow(id) {
  if (!supabase) return { error: null };
  return supabase.from("cobrancas").delete().eq("id", id);
}

// ─── COMPONENTS ─────────────────────────────────────────────────────────────
function Badge({ status }) {
  const s = STATUS_STYLE[status] || STATUS_STYLE["Pendente"];
  const Icon = s.icon;
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${s.bg} ${s.text} ${s.border}`}>
      <Icon size={11} />{status}
    </span>
  );
}

function KPICard({ label, value, sub, color, icon: Icon, alert }) {
  return (
    <div className={`relative rounded-2xl border p-5 flex flex-col gap-2 ${alert ? "border-red-500/60 bg-red-950/20" : "border-zinc-800 bg-zinc-900/60"}`}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-zinc-400 uppercase tracking-widest">{label}</span>
        <span className={`p-2 rounded-xl ${alert ? "bg-red-900/40 text-red-400" : "bg-zinc-800 text-zinc-400"}`}><Icon size={16}/></span>
      </div>
      <span className={`text-2xl font-black ${color}`}>{value}</span>
      {sub && <span className="text-xs text-zinc-500">{sub}</span>}
      {alert && <div className="absolute top-3 right-3 w-2 h-2 rounded-full bg-red-500 animate-pulse"/>}
    </div>
  );
}

function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-zinc-900 border border-zinc-700 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="flex items-center justify-between p-6 border-b border-zinc-800">
          <h2 className="text-lg font-bold text-white">{title}</h2>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors"><X size={18}/></button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}

const emptyForm = () => ({
  codigo_cliente: "", nome_cliente: "", numero_nota: "",
  valor_total: "", valor_recebido: "0",
  forma_pagamento: "Boleto", data_vencimento: today(),
  status: "Pendente", observacoes: "",
});

// ─── MAIN APP ────────────────────────────────────────────────────────────────
export default function App() {
  const [rows, setRows]         = useState([]);
  const [loading, setLoading]   = useState(true);
  const [search, setSearch]     = useState("");
  const [filterStatus, setFilterStatus] = useState("Todos");
  const [sortCol, setSortCol]   = useState("data_vencimento");
  const [sortDir, setSortDir]   = useState("asc");
  const [modal, setModal]       = useState(null); // "new" | "edit" | "delete"
  const [activeRow, setActiveRow] = useState(null);
  const [form, setForm]         = useState(emptyForm());
  const [saving, setSaving]     = useState(false);
  const [toast, setToast]       = useState(null);
  const [tab, setTab]           = useState("dashboard"); // "dashboard" | "tabela"

  const showToast = (msg, type = "ok") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await fetchRows();
    if (error) showToast("Erro ao carregar dados: " + error.message, "err");
    else setRows(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  // ── KPIs ──
  const isOverdue = (r) => {
    if (r.status === "Pago Total" || r.status === "Cancelado") return false;
    return isAfter(new Date(), parseISO(r.data_vencimento));
  };
  const overdue      = rows.filter(isOverdue);
  const partialOverdue = rows.filter(r => isOverdue(r) && r.status === "Pago Parcial");
  const totalAtrasado  = overdue.reduce((s, r) => s + (Number(r.valor_total) - Number(r.valor_recebido || 0)), 0);
  const totalPendente  = rows.filter(r => r.status === "Pendente").reduce((s, r) => s + Number(r.valor_total), 0);
  const totalRecebido  = rows.reduce((s, r) => s + Number(r.valor_recebido || 0), 0);

  // ── TABLE ──
  const filtered = rows
    .filter(r => {
      const q = search.toLowerCase();
      return (
        r.codigo_cliente?.toLowerCase().includes(q) ||
        r.nome_cliente?.toLowerCase().includes(q) ||
        r.numero_nota?.toLowerCase().includes(q)
      );
    })
    .filter(r => filterStatus === "Todos" || r.status === filterStatus)
    .sort((a, b) => {
      let av = a[sortCol] ?? "", bv = b[sortCol] ?? "";
      if (sortCol === "valor_total" || sortCol === "valor_recebido") { av = +av; bv = +bv; }
      return sortDir === "asc" ? (av > bv ? 1 : -1) : (av < bv ? 1 : -1);
    });

  const sort = (col) => {
    if (sortCol === col) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortCol(col); setSortDir("asc"); }
  };

  const SortIcon = ({ col }) => sortCol === col
    ? (sortDir === "asc" ? <ChevronUp size={12}/> : <ChevronDown size={12}/>)
    : <ChevronDown size={12} className="opacity-30"/>;

  // ── CRUD ──
  const openNew  = () => { setForm(emptyForm()); setModal("new"); };
  const openEdit = (r) => { setActiveRow(r); setForm({ ...r, valor_total: String(r.valor_total), valor_recebido: String(r.valor_recebido || 0) }); setModal("edit"); };
  const openDel  = (r) => { setActiveRow(r); setModal("delete"); };

  const handleSave = async () => {
    if (!form.codigo_cliente || !form.numero_nota || !form.valor_total) {
      showToast("Preencha os campos obrigatórios.", "err"); return;
    }
    setSaving(true);
    const payload = {
      ...form,
      valor_total: parseFloat(form.valor_total),
      valor_recebido: parseFloat(form.valor_recebido || 0),
      id: modal === "edit" ? activeRow.id : undefined,
    };
    const { error } = await upsertRow(payload);
    setSaving(false);
    if (error) { showToast("Erro: " + error.message, "err"); return; }
    showToast(modal === "edit" ? "Cobrança atualizada!" : "Cobrança cadastrada!");
    setModal(null);
    load();
  };

  const handleDelete = async () => {
    setSaving(true);
    const { error } = await deleteRow(activeRow.id);
    setSaving(false);
    if (error) { showToast("Erro: " + error.message, "err"); return; }
    showToast("Cobrança removida.");
    setModal(null);
    load();
  };

  const handleTogglePago = async (r) => {
    const newStatus = r.status === "Pago Total" ? "Pendente" : "Pago Total";
    const newValorRecebido = newStatus === "Pago Total" ? r.valor_total : 0;
    await upsertRow({ ...r, status: newStatus, valor_recebido: newValorRecebido });
    load();
  };

  // ── RENDER ──
  return (
    <div className="min-h-screen bg-zinc-950 text-white" style={{ fontFamily: "'DM Sans', 'Segoe UI', sans-serif" }}>
      {/* TOAST */}
      {toast && (
        <div className={`fixed top-4 right-4 z-[100] flex items-center gap-2 px-4 py-3 rounded-xl shadow-2xl text-sm font-semibold border ${toast.type === "err" ? "bg-red-950 border-red-700 text-red-300" : "bg-emerald-950 border-emerald-700 text-emerald-300"}`}>
          {toast.type === "err" ? <XCircle size={16}/> : <CheckCircle2 size={16}/>}
          {toast.msg}
        </div>
      )}

      {/* HEADER */}
      <header className="border-b border-zinc-800 bg-zinc-900/80 backdrop-blur sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-indigo-600/20 border border-indigo-500/30">
              <FileText size={20} className="text-indigo-400"/>
            </div>
            <div>
              <h1 className="text-lg font-black text-white leading-none">Controle de Cobranças</h1>
              <p className="text-xs text-zinc-500 mt-0.5">Fábrica Online · Sistema de Recebíveis</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {!SUPABASE_URL && (
              <span className="text-xs bg-amber-900/30 border border-amber-700/50 text-amber-400 px-3 py-1.5 rounded-full font-medium">
                ⚠ Modo Demo — Configure o Supabase
              </span>
            )}
            <button onClick={load} className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white transition-all" title="Atualizar">
              <RefreshCw size={16} className={loading ? "animate-spin" : ""}/>
            </button>
            <button onClick={openNew} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 rounded-xl text-sm font-semibold transition-all shadow-lg shadow-indigo-900/40">
              <Plus size={16}/>Nova NF
            </button>
          </div>
        </div>

        {/* TABS */}
        <div className="max-w-7xl mx-auto px-4 pb-0 flex gap-1">
          {["dashboard", "tabela"].map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-5 py-2.5 text-sm font-semibold rounded-t-xl transition-all capitalize ${tab === t ? "bg-zinc-950 text-white border-t border-l border-r border-zinc-700" : "text-zinc-500 hover:text-zinc-300"}`}>
              {t === "dashboard" ? "📊 Dashboard" : "📋 Cobranças"}
            </button>
          ))}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">

        {/* ═══ DASHBOARD ═══════════════════════════════════════════════════ */}
        {tab === "dashboard" && (
          <div className="space-y-6">
            {/* KPIs */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <KPICard label="Em Atraso" value={overdue.length} sub={`${fmtBRL(totalAtrasado)} a receber`} color="text-red-400" icon={AlertTriangle} alert={overdue.length > 0}/>
              <KPICard label="Parcial Atrasado" value={partialOverdue.length} sub="Pagamento incompleto" color="text-amber-400" icon={TrendingUp} alert={partialOverdue.length > 0}/>
              <KPICard label="Pendente" value={rows.filter(r=>r.status==="Pendente").length} sub={fmtBRL(totalPendente)} color="text-blue-300" icon={Clock}/>
              <KPICard label="Total Recebido" value={fmtBRL(totalRecebido)} sub={`${rows.filter(r=>r.status==="Pago Total").length} NFs quitadas`} color="text-emerald-400" icon={DollarSign}/>
            </div>

            {/* Boletos Atrasados */}
            <div className="rounded-2xl border border-red-900/40 bg-red-950/10 overflow-hidden">
              <div className="flex items-center gap-3 px-6 py-4 border-b border-red-900/30">
                <AlertTriangle size={18} className="text-red-400"/>
                <h2 className="font-bold text-red-300">NFs com Boleto Atrasado</h2>
                <span className="ml-auto bg-red-900/50 text-red-300 text-xs font-bold px-2.5 py-1 rounded-full border border-red-800/50">{overdue.length}</span>
              </div>
              {overdue.length === 0 ? (
                <div className="p-8 text-center text-zinc-500 text-sm">
                  <CheckCircle2 size={32} className="mx-auto mb-2 text-emerald-600/50"/>
                  Nenhum boleto em atraso 🎉
                </div>
              ) : (
                <div className="divide-y divide-red-900/20">
                  {overdue.map(r => {
                    const dias = differenceInDays(new Date(), parseISO(r.data_vencimento));
                    const saldo = Number(r.valor_total) - Number(r.valor_recebido || 0);
                    return (
                      <div key={r.id} className="px-6 py-4 flex flex-wrap items-center gap-4 hover:bg-red-900/10 transition-colors">
                        <div className="flex-1 min-w-48">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white text-sm">{r.numero_nota}</span>
                            <Badge status={r.status}/>
                          </div>
                          <p className="text-xs text-zinc-400 mt-0.5">{r.nome_cliente} · {r.codigo_cliente}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-zinc-500">Vencimento</p>
                          <p className="text-sm font-semibold text-red-300">{format(parseISO(r.data_vencimento), "dd/MM/yyyy")}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-zinc-500">Dias em atraso</p>
                          <p className="text-sm font-black text-red-400">{dias}d</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-zinc-500">Saldo devedor</p>
                          <p className="text-sm font-bold text-red-300">{fmtBRL(saldo)}</p>
                        </div>
                        {r.observacoes && (
                          <div className="w-full">
                            <p className="text-xs text-amber-400/80 bg-amber-900/20 border border-amber-800/30 rounded-lg px-3 py-1.5">💬 {r.observacoes}</p>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Status geral */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {STATUS_OPTIONS.map(s => {
                const cnt = rows.filter(r => r.status === s).length;
                const st = STATUS_STYLE[s];
                return (
                  <div key={s} className={`rounded-xl border p-4 text-center ${st.bg} ${st.border}`}>
                    <p className={`text-2xl font-black ${st.text}`}>{cnt}</p>
                    <p className={`text-xs mt-1 ${st.text} opacity-80`}>{s}</p>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ═══ TABELA ══════════════════════════════════════════════════════ */}
        {tab === "tabela" && (
          <div className="space-y-4">
            {/* Filtros */}
            <div className="flex flex-wrap gap-3 items-center">
              <div className="relative flex-1 min-w-56">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500"/>
                <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Buscar cliente, código, NF..."
                  className="w-full pl-9 pr-3 py-2.5 bg-zinc-900 border border-zinc-700 rounded-xl text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500"/>
              </div>
              <div className="relative">
                <Filter size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500"/>
                <select value={filterStatus} onChange={e=>setFilterStatus(e.target.value)}
                  className="pl-8 pr-4 py-2.5 bg-zinc-900 border border-zinc-700 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500 appearance-none">
                  <option>Todos</option>
                  {STATUS_OPTIONS.map(s=><option key={s}>{s}</option>)}
                </select>
              </div>
              <span className="text-xs text-zinc-500 ml-auto">{filtered.length} registros</span>
            </div>

            {/* Table */}
            <div className="rounded-2xl border border-zinc-800 bg-zinc-900/40 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-zinc-800 bg-zinc-900">
                      {[
                        ["codigo_cliente","Cód. Cliente"],["numero_nota","Nota Fiscal"],
                        ["nome_cliente","Cliente"],["valor_total","Valor Total"],
                        ["valor_recebido","Recebido"],["forma_pagamento","Pagamento"],
                        ["data_vencimento","Vencimento"],["status","Status"],
                      ].map(([col,label])=>(
                        <th key={col} onClick={()=>sort(col)} className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wider cursor-pointer hover:text-white transition-colors select-none whitespace-nowrap">
                          <span className="flex items-center gap-1">{label}<SortIcon col={col}/></span>
                        </th>
                      ))}
                      <th className="px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wider">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/50">
                    {loading ? (
                      <tr><td colSpan={9} className="text-center py-12 text-zinc-500">
                        <RefreshCw size={24} className="animate-spin mx-auto mb-2 opacity-40"/>Carregando...
                      </td></tr>
                    ) : filtered.length === 0 ? (
                      <tr><td colSpan={9} className="text-center py-12 text-zinc-500">Nenhum registro encontrado.</td></tr>
                    ) : filtered.map(r => {
                      const atrasado = isOverdue(r);
                      const saldo = Number(r.valor_total) - Number(r.valor_recebido || 0);
                      return (
                        <tr key={r.id} className={`hover:bg-zinc-800/40 transition-colors ${atrasado ? "bg-red-950/10" : ""}`}>
                          <td className="px-4 py-3 font-mono text-xs text-indigo-400">{r.codigo_cliente}</td>
                          <td className="px-4 py-3 font-semibold text-white whitespace-nowrap">{r.numero_nota}
                            {atrasado && <span className="ml-2 inline-block w-2 h-2 rounded-full bg-red-500 animate-pulse" title="Atrasado"/>}
                          </td>
                          <td className="px-4 py-3 text-zinc-300 max-w-48 truncate">{r.nome_cliente}</td>
                          <td className="px-4 py-3 font-semibold text-white whitespace-nowrap">{fmtBRL(r.valor_total)}</td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <span className={saldo > 0 && saldo < Number(r.valor_total) ? "text-amber-400 font-semibold" : "text-zinc-300"}>{fmtBRL(r.valor_recebido || 0)}</span>
                            {saldo > 0 && Number(r.valor_recebido) > 0 && <span className="text-xs text-red-400 block">falta {fmtBRL(saldo)}</span>}
                          </td>
                          <td className="px-4 py-3 text-zinc-400">{r.forma_pagamento}</td>
                          <td className={`px-4 py-3 whitespace-nowrap font-medium ${atrasado ? "text-red-400" : "text-zinc-300"}`}>
                            {format(parseISO(r.data_vencimento), "dd/MM/yyyy")}
                            {atrasado && <span className="text-xs block text-red-500">{differenceInDays(new Date(), parseISO(r.data_vencimento))}d atraso</span>}
                          </td>
                          <td className="px-4 py-3"><Badge status={r.status}/></td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-1">
                              <button onClick={()=>handleTogglePago(r)} title={r.status==="Pago Total"?"Marcar pendente":"Marcar pago"}
                                className={`p-1.5 rounded-lg transition-all ${r.status==="Pago Total" ? "bg-emerald-900/30 text-emerald-400 hover:bg-emerald-900/60" : "bg-zinc-800 text-zinc-400 hover:text-emerald-400 hover:bg-emerald-900/20"}`}>
                                <CheckCircle2 size={14}/>
                              </button>
                              <button onClick={()=>openEdit(r)} className="p-1.5 rounded-lg bg-zinc-800 text-zinc-400 hover:text-indigo-400 hover:bg-indigo-900/20 transition-all">
                                <FileText size={14}/>
                              </button>
                              <button onClick={()=>openDel(r)} className="p-1.5 rounded-lg bg-zinc-800 text-zinc-400 hover:text-red-400 hover:bg-red-900/20 transition-all">
                                <X size={14}/>
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* ═══ MODAL FORM ══════════════════════════════════════════════════════ */}
      {(modal === "new" || modal === "edit") && (
        <Modal title={modal === "new" ? "Nova Cobrança" : "Editar Cobrança"} onClose={()=>setModal(null)}>
          <div className="grid grid-cols-2 gap-4">
            {[
              ["codigo_cliente","Código do Cliente *","text",true],
              ["nome_cliente","Nome do Cliente","text",false],
              ["numero_nota","Número da Nota Fiscal *","text",true],
              ["data_vencimento","Data de Vencimento *","date",true],
              ["valor_total","Valor Total (R$) *","number",true],
              ["valor_recebido","Valor Recebido (R$)","number",false],
            ].map(([field, label, type, req]) => (
              <div key={field} className={field === "nome_cliente" || field === "observacoes" ? "col-span-2" : ""}>
                <label className="block text-xs font-semibold text-zinc-400 mb-1.5">{label}</label>
                <input type={type} value={form[field]} onChange={e=>setForm(f=>({...f,[field]:e.target.value}))}
                  min={type === "number" ? "0" : undefined} step={type === "number" ? "0.01" : undefined}
                  className="w-full px-3 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-indigo-500 placeholder-zinc-600"/>
              </div>
            ))}
            <div>
              <label className="block text-xs font-semibold text-zinc-400 mb-1.5">Forma de Pagamento</label>
              <select value={form.forma_pagamento} onChange={e=>setForm(f=>({...f,forma_pagamento:e.target.value}))}
                className="w-full px-3 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-indigo-500">
                {PAYMENT_FORMS.map(p=><option key={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-zinc-400 mb-1.5">Status</label>
              <select value={form.status} onChange={e=>setForm(f=>({...f,status:e.target.value}))}
                className="w-full px-3 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-indigo-500">
                {STATUS_OPTIONS.map(s=><option key={s}>{s}</option>)}
              </select>
            </div>
            <div className="col-span-2">
              <label className="block text-xs font-semibold text-zinc-400 mb-1.5">Observações</label>
              <textarea value={form.observacoes} onChange={e=>setForm(f=>({...f,observacoes:e.target.value}))} rows={2}
                className="w-full px-3 py-2.5 bg-zinc-800 border border-zinc-700 rounded-xl text-white text-sm focus:outline-none focus:border-indigo-500 resize-none"/>
            </div>
          </div>
          <div className="flex gap-3 mt-6 justify-end">
            <button onClick={()=>setModal(null)} className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-sm font-semibold transition-all">Cancelar</button>
            <button onClick={handleSave} disabled={saving} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-sm font-semibold transition-all disabled:opacity-50">
              <Save size={15}/>{saving ? "Salvando..." : "Salvar"}
            </button>
          </div>
        </Modal>
      )}

      {/* ═══ MODAL DELETE ════════════════════════════════════════════════════ */}
      {modal === "delete" && activeRow && (
        <Modal title="Confirmar Exclusão" onClose={()=>setModal(null)}>
          <p className="text-zinc-300 text-sm mb-2">Deseja remover a cobrança abaixo?</p>
          <div className="bg-zinc-800 rounded-xl p-4 mb-6">
            <p className="font-bold text-white">{activeRow.numero_nota}</p>
            <p className="text-xs text-zinc-400 mt-1">{activeRow.nome_cliente} · {fmtBRL(activeRow.valor_total)}</p>
          </div>
          <div className="flex gap-3 justify-end">
            <button onClick={()=>setModal(null)} className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-sm font-semibold transition-all">Cancelar</button>
            <button onClick={handleDelete} disabled={saving} className="px-5 py-2.5 rounded-xl bg-red-700 hover:bg-red-600 text-sm font-semibold transition-all disabled:opacity-50">
              {saving ? "Removendo..." : "Remover"}
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
